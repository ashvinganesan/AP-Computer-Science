/*
Ashvin Ganesan
APCS Unit 4 Lab 2
11/01/2019
 */
public class Runner {
    public static void main(String[] args) {
        U4L2 demo = new U4L2();
        demo.factorial(5);
        demo.factorial(4);
        demo.factorial(8);
        demo.factorial(15);
        demo.factorial(6);
        demo.factorial(9);
        demo.factorial(3);
        demo.countCoolNumbers(250);
        demo.countCoolNumbers(1250);
        demo.countCoolNumbers(2250);
        demo.countCoolNumbers(5500);
        demo.countCoolNumbers(9500);
        demo.countCoolNumbers(23500);
        demo.countCoolNumbers(32500);
        demo.fancyTriange("hippo");
        demo.fancyTriange("abcd");
        demo.fancyTriange("it");
        demo.fancyTriange("a");
        demo.fancyTriange("chicken");
        demo.generateTable(5, 5);
        demo.generateTable(3, 7);
        demo.generateTable(1, 6);
        demo.generateTable(9, 9);
        demo.backwardString("Hello");
        demo.backwardString("World");
        demo.backwardString("JukeBox");
        demo.backwardString("TCEA");
        
        
    }
    
    
}
