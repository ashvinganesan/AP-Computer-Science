/*  Ashvin Ganesan
 * APCS  Unit 4 - Lab 1  
 * 10/7/2019  */
public class Runner {
    public static void main(String[] args) {
        U4L1 test = new U4L1();
        test.countDigits(234);
        test.countDigits(10000);
        test.countDigits(111);
        test.countDigits(9005);
        test.countDigits(84645);
        test.countDigits(8547);
        test.countDigits(123456789);
        test.averageDigit(234);
        test.averageDigit(10000);
        test.averageDigit(111);
        test.averageDigit(9005);
        test.averageDigit(84645);
        test.averageDigit(8547);
        test.averageDigit(123456789);
        test.findDivisors(10);
        test.findDivisors(45);
        test.findDivisors(14);
        test.findDivisors(1024);
        test.findDivisors(1245);
        test.findDivisors(33);
        test.findDivisors(65535); 
        test.isPrime(1);
        test.isPrime(2);
        test.isPrime(3);
        test.isPrime(4);
        test.isPrime(5);
        test.isPrime(6);
        test.isPrime(7);
        test.isPrime(8);
        test.isPrime(9);
    }
    
    
    
}
