/* 
Ashvin Ganesan 
AP CS Unit 
2-Lab 2 09/16/2019
*/
public class Runner {

   public static void main (String[] args) {
        String prioryAddress = "302 Portola Rd. Portola Valley, CA 94028";
	U2L2 test = new U2L2();
        test.addressExtractor(prioryAddress);
   }

   
}