/*
Ashvin Ganesan
Ms. Hemiup APCS Unit 9 Lab 1
Friday January 31st 2019
 */
//the goal of this lab was to extend off of other classes and to gain more practice with them.
public class Runner {
    public static void main(String[] args) {
//        StudentAdvance demo = new StudentAdvance(3000,9);
//        //Advance demo2 = new Advance(200, 10);
//        Advance demo2 = new Advance(200, 9);       
//        Walkup demo3 = new Walkup(1999);
//        Ticket demo4 = new Ticket(10000, 50.5);
//        System.out.println(demo4);
//        System.out.println("");
//        System.out.println(demo3);
//        System.out.println("");
//        System.out.println(demo2);
//        System.out.println("");
//        System.out.println(demo);
        //Cars car = new Cars(2, true, 19.8);
//        Cars car = new Cars(2, false, 19.8);
//        System.out.println(car);
        AudioBook test = new AudioBook(100, "a book", 20);
        System.out.println(test);

        
    }
}
